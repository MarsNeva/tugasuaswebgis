<ul class="nav navbar-nav navbar-left navbar-top-links">
        <li><a href="<?= base_url() ?>"><i class="fa fa-home fa-fw"></i> Home</a></li>
        <li><a href="<?= base_url('home/global') ?>"></i> Global</a></li>
        <li><a href="<?= base_url('home/pemetaanglobal') ?>"></i> Pemetaan Global</a></li>
        <li><a href="<?= base_url('home/pemetaannasional') ?>"></i> Pemetaan Nasional</a></li>
    </ul>


   
</nav>

<!-- Page Content -->
<div id="wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <h1 class="page-header"><?= $title ?></h1>
           