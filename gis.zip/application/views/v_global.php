
                        <div class="col-lg-4 col-md-12">
                            <div class="panel panel-yellow">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-heart-o fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?= $positif['value'] ?></div>
                                            <div>Total Positif</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="panel panel-green">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-heart fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?= $sembuh['value'] ?></div>
                                            <div>Total Sembuh</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="panel panel-red">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-ambulance fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?= $meninggal['value'] ?></div>
                                            <div>Total Meninggal</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                         <!-- /.col-lg-4 -->
                         <div class="col-lg-12 col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading text-center">
                                Data Kasus Coronavirus Global Berdasarkan Negara
                                </div>
                                <div class="panel-body">
                                <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                                <tr>
                                                    <th class="text-center" style="width:50px">No</th>
                                                    <th class="text-center">Negara</th>
                                                    <th class="text-center" style="width:200px">Positif</th>
                                                    <th class="text-center" style="width:200px">Sembuh</th>
                                                    <th class="text-center" style="width:200px">Meninggal</th>
                                                </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no=1; foreach ($global as $key => $value) { ?>
                                            
                                            <tr>
                                                <td class="text-center"><?= $no++ ?></td>
                                                <td><?= $value['attributes']['Country_Region']  ?></td>
                                                <td class="text-center"><?= $value['attributes']['Confirmed']  ?></td>
                                                <td class="text-center"><?= $value['attributes']['Recovered']  ?></td>
                                                <td class="text-center"><?= $value['attributes']['Deaths']  ?></td>
                                            </tr>
                                        <?php } ?>
                                        </tbody>
                                   </table>

                                </div>
                                </div>
                            </div>
                        </div>